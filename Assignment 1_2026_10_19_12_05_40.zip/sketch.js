//Author: Peter Kirwan
//Date// 06/10/2026
//Purpose: Assignment 1
  
//declared variables

var x = 100;
var bg;
var z = 650;
var y = 300;
  


//async function found in guide provided

async function setup() {
  bg=await loadImage('commeraghs.png')
  createCanvas(800, 800);

  
  
}


function draw() {
  

image(bg, 0, 0, 800, 800);
  
  house();

  car();

  driveway();

  moon(); 

  spaceship();
  
  greencircle();

//multiple birds called from drawBird function
  drawBird (50,50,1) ;
  drawBird (50,150,0.5);
  drawBird (150,125,0.75);
  drawBird (160,50,0.5);
  drawBird (225,75,0.75);


//tool to find x + y coordinates.
//fill(255);
//textSize(20);
//text("X: " + mouseX + " Y: " + mouseY, 20, 20);

  
} 

//functions used to move the green circle in different directions using z + y variables previously declared using keypressed function below

function moveRight() {
  if(z<750) {
  z=z+5}
  
}
function moveLeft() {
  if(z>50) {
  z=z-5 }
  
}
function moveUp() {
  if(y>50) {
  y=y-5 }
  
}
function moveDown() {
  if(y<750) {
  y=y+5 }

  //this is where i have added in ducks into the sky using functions in draw to call multiple instances with different paramaters 
}
  function drawBird(x,y,size) {
  strokeWeight(1)
  fill("yellow");
  ellipse(x,y,100*size,65*size);
  circle(x+35*size,y-25*size,50*size);
  fill(0);
  circle(x+45*size,y-30*size,5*size);
  fill("orange");
  triangle(x+55*size,y-25*size,x+75*size,y-18*size,x+55*size,y-12*size);
  ellipse(x,y,45*size,30*size);
  stroke(5);
  line(x-10*size,y+30*size,x-10*size,y+45*size);
  line(x+10*size,y+30*size,x+10*size,y+45*size);
  
    
  }
  function greencircle() {
  fill(0, 255, 0);
  circle(z, y, 100);
  
}

  
  function spaceship(x,y) {
  strokeWeight(0)
  fill(random(255),random(255),random(255));
  circle(450,600,40)
  circle(500,600,40)
  circle(550,600,40)
  fill(255,0,0)
  circle(500,470,150)
  triangle(500,400,600,600,400,600)
  fill(random(255),random(255),random(255));
  circle(450,450,30)
  circle(500,450,30)
  circle(550,450,30)
  }
  
  
  

function house() { 
  fill(255,255,190)
  rect(50,400,300,399)
  fill(75)
  triangle(200,300,360,400,40,400)
  strokeWeight(0)
  rect(270,300,40,90)
  strokeWeight(2)
  fill(175,215,225)
  rect(70,450,80,80)
  rect(70,575,80,80)
  rect(250,575,80,80)
  line(110,450,110,530)
  line(70,490,150,490)
  line(110,575,110,655)
  line(70,615,150,615)
  line(250,615,330,615)
  line(290,575,290,655)
//If else statement used for lights to come on in upper right window using system variables
  if ((mouseX >150) && (mouseX <250) && (mouseY >600) && (mouseY) < 800) {
  fill(random(255), random(255), random(255)); 
  
} else {
  fill(175, 215, 225);
} rect(250,450,80,80)
  line(290,450,290,530)
  line(250,490,330,490)
  fill(150,75,0)
  rect(160,650,80,150)
  rect(165,660,70,70)
  circle(200,750,10)  
}

function car() { 
  strokeWeight(3)
  fill(250,105,40)
  rect(500,670,250,80)
  line(595,670,595,750)
  fill(0)
  ellipse(610,680,15,5)
  fill(250,150,80)
  rect(520,640,130,30)
  line(650,640,750,670)
  fill("yellow")
  ellipse (735,680,25,15)
  fill(0)
  circle(540,750,50)
  circle(710,750,50)
  fill(150)
  circle(540,750,30)
  circle(712,750,30)

}

function driveway() {
  fill(0)
  rect(350,770,500,400)
}
function moon() {
  strokeWeight(0);
  fill(255);
  circle(x, 150, 150);
  x = x + 1;
  if (x > width + 75) {
  x = x - 950;
}
}

  
  function keyPressed () {
  //had to use number keycodes as per p5.js guides
  if (keyCode === 39) {
    moveRight();
  }

  if (keyCode === 37) {
    moveLeft();
  }

  if (keyCode === 38) {
    moveUp();
  }

  if (keyCode === 40) {
    moveDown();
  }



    
  }
    

